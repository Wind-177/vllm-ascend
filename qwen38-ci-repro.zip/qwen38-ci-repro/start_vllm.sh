#!/usr/bin/env bash
# Run inside the same Linux/A3 software environment as the CI job.
set -eo pipefail
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES="${ASCEND_RT_VISIBLE_DEVICES:-0,1}"
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export OMP_NUM_THREADS=1
export TASK_QUEUE_ENABLE=1
export HCCL_OP_EXPANSION_MODE=AIV
export HCCL_BUFFSIZE=1024
export VLLM_USE_MODELSCOPE=true
vllm serve Eco-Tech/Qwen3.8-27B-w8a8 \
  --data-parallel-size 1 \
  --tensor-parallel-size 2 \
  --port 8000 \
  --max-model-len 133120 \
  --enable-prefix-caching \
  --max-num-batched-tokens 16384 \
  --max-num-seqs 32 \
  --gpu-memory-utilization 0.9 \
  --compilation-config '{"cudagraph_capture_sizes":[1,4,8,12,16,20,24,28,32,36,40,44,48,52,56,60,64,68,72,76,80,84,88,92,96,100,104,108,112,116,120,124,128],"cudagraph_mode":"FULL_DECODE_ONLY"}' \
  --speculative_config '{"method":"qwen3_5_mtp","num_speculative_tokens":3}' \
  --trust-remote-code \
  --async-scheduling \
  --allowed-local-media-path / \
  --quantization ascend \
  --mm-processor-cache-gb 0 \
  --mm-encoder-tp-mode data \
  --mm-processor-cache-type shm \
  --additional-config '{"enable_cpu_binding":true}' \
  --api-server-count 4 2>&1 | tee vllm-repro.log
