"""Install the two captured CI configs into the active AISBench installation."""
import argparse
import ast
from pathlib import Path
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--model-path", required=True, help="Local tokenizer/model directory")
parser.add_argument("--dataset-path", required=True, help="Root of the original GSM8K prefix90 dataset")
parser.add_argument("--host", default="localhost")
parser.add_argument("--port", type=int, default=8000)
parser.add_argument("--config-root", type=Path, help="Optional AISBench configs directory")
args = parser.parse_args()
for value in (args.model_path, args.dataset_path):
    if not Path(value).is_dir():
        parser.error(f"Directory does not exist: {value}")
if args.config_root is None:
    import ais_bench.benchmark
    config_root = Path(next(iter(ais_bench.benchmark.__path__))) / "configs"
else:
    config_root = args.config_root
if not config_root.is_dir():
    parser.error(f"AISBench configs directory does not exist: {config_root}")
source = Path(__file__).resolve().parent
model = (source / "vllm_api_stream_chat_custom.py").read_text(encoding="utf-8")
model, count = re.subn(r"(?m)^(\s*)path=.*$", lambda m: f"{m[1]}path={args.model_path!r},", model)
assert count == 1
model = re.sub(r"(?m)^(\s*)host_port=.*$", lambda m: f"{m[1]}host_port={args.port},", model)
model = re.sub(r"(?m)^(\s*)host_ip=.*$", lambda m: f"{m[1]}host_ip={args.host!r},", model)
dataset = (source / "gsm8k_gen_0_shot_cot_str_perf_custom.py").read_text(encoding="utf-8")
dataset, count = re.subn(r"(?m)^(\s*)path=.*$", lambda m: f"{m[1]}path={args.dataset_path!r},", dataset)
assert count == 1
for relative, content in (
    ("models/vllm_api/vllm_api_stream_chat_custom.py", model),
    ("datasets/gsm8k/gsm8k_gen_0_shot_cot_str_perf_custom.py", dataset),
):
    ast.parse(content)
    target = config_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    print(target)
