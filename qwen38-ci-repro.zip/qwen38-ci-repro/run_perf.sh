#!/usr/bin/env bash
set -eo pipefail
# Run once after service readiness, as the CI completion sanity check.
curl --fail --silent --show-error http://localhost:8000/v1/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"Eco-Tech/Qwen3.8-27B-w8a8","prompt":["San Francisco is a"],"max_tokens":10}'
printf '\n'
ais_bench \
  --models vllm_api_stream_chat_custom \
  --datasets gsm8k_gen_0_shot_cot_str_perf_custom \
  --mode perf \
  --num-prompts 24 \
  --debug > output_performance.txt 2>&1
